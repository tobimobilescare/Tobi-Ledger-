TOBI LEDGER — ANDROID STUDIO PROJECT

Branding has been updated to Tobi Ledger.

This is an Android Studio source project, not a compiled APK.

FEATURES
- Offline-first Android WebView app
- Separate Shop and Home accounts
- Income, sales, expenses, purchases and savings
- Multiple supplier accounts
- Credit purchases and supplier payment tracking
- Edit/delete transactions
- PIN lock
- JSON backup and restore

BUILD THE APK
1. Install Android Studio on a computer.
2. Extract this ZIP and open the Tobi_Ledger_Android_Project folder in Android Studio.
3. Allow Gradle Sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK, normally at:
   app/build/outputs/apk/debug/app-debug.apk

IMPORTANT
- This environment cannot compile/sign the APK because Android SDK/Gradle build tools are unavailable here.
- Records are stored in local WebView storage on this device. Uninstalling or clearing app data may erase records.
- Export backups regularly and keep them somewhere safe.
- The PIN is a basic local app lock, not bank-grade security.
